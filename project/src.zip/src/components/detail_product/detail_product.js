import './detail_product.css'
function DetailProduct(){
    return(
        <div className='DetailProduct'>
            DetailProduct
        </div>
    )
}
export default DetailProduct;